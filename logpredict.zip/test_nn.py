__author__ = 'Sourabh'
import re
from scipy import *
from sklearn.neural_network import BernoulliRBM
from sklearn import svm
from sklearn.datasets import load_iris
from classes import features

from classes.features2 import *

class NN:
    logfile_uniquewords = {}
    uniquelogwords = {}
    uniquewords_map = {}
    map_index = 0
    lognum = 0

    def setClass(self):
        category_words = features.Features.categories

    def readLogfile (self, filetoread):
        with open(filetoread, 'r') as f:
            logmessages = f.readlines()
        f.close()
        self.lognum+=1
        return logmessages

    def printlog (self, logmessage):
        for line in logmessage:
            print (line)

    def getUniqueWordCount(self, logfile ):
        self.uniquelogwords.clear()
        datetime = '\d{2}\:\d{2}\:\d{2}\,\d{3}'
        characters = '\='
        rg = re.compile(datetime,re.IGNORECASE|re.DOTALL)
        rc = re.compile(characters, re.IGNORECASE|re.DOTALL)
        for line in logfile:
            words = line.split()
            for word in words:
                #if rg.match(word) or rc.match(word): words.remove(word)
                if (word in self.uniquelogwords.keys()): self.uniquelogwords[word]+=1
                else: self.uniquelogwords[word]=1
                #self.addReference(word)

    def addReference(self, word):
        if word in self.uniquewords_map.values():
            return
        else:
            self.uniquewords_map[self.map_index]=word
            self.map_index += 1

    def printUniqueWords(self, choice):
        if choice == 1:
            print (self.uniquelogwords.__len__())
            for log, wordlist in self.logfile_uniquewords.iteritems():
                print ("Log#"),log
                for word, count in wordlist.items():
                    print (word, count)
        elif choice == 2:
            print (self.uniquelogwords.__len__())
            for word, count in self.uniquewords_map.iteritems():
                print (word, count)

        else:
            print ("Incorrect option")

    def normalizeWordCount(self):
        total = sum(self.uniquelogwords.values())
        for word, count in self.uniquelogwords.iteritems():
            self.uniquelogwords[word]=float(count)/float(total)
        self.logfile_uniquewords[self.lognum]=self.uniquelogwords.copy()

    def trimWords(self):
        for word, count in self.uniquelogwords.iteritems():
            if count > 0.004:
                self.uniquelogwords.popitem()

    def extractFeatures(self):
        for log, log_keywords in self.logfile_uniquewords.iteritems():
            if (log_keywords.has_key("-b")):
                feature1=log_keywords["-b"]
            else: feature1=0

            if (log_keywords.has_key("Static")):
                feature2=log_keywords["Static"]
            else: feature2=0

            if (log_keywords.has_key("-logfile")):
                feature3=log_keywords["-logfile"]
            else: feature3=0

            if (log_keywords.has_key("com.fortify.SCAExecutablePath=")):
                feature4=log_keywords["com.fortify.SCAExecutablePath="]
            else: feature4=0

            if (log_keywords.has_key("SCA")):
                feature5=log_keywords["SCA"]
            else: feature5=0

            if (log_keywords.has_key("Preprocessor")):
                feature6=log_keywords["Preprocessor"]
            else: feature6=0

            if (log_keywords.has_key("[10234]")):
                feature7=log_keywords["[10234]"]
            else: feature7=0

            if (log_keywords.has_key("S/MIME")):
                feature8=log_keywords["S/MIME"]
            else: feature8=0

            if (log_keywords.has_key("server")):
                feature9=log_keywords["server"]
            else: feature9=0

            if (log_keywords.has_key("'path-type'")):
                feature10=log_keywords["'path-type'"]
            else: feature10=0

            if (log_keywords.has_key("[WARN]")):
                feature11=log_keywords["[WARN]"]
            else: feature11=0

            if (log_keywords.has_key("com.fortify.sca.Debug=")):
                feature12=log_keywords["com.fortify.sca.Debug="]
            else: feature12=0


            features = (feature1, feature2, feature3, feature4, feature5, feature6, feature7, feature8, feature9, feature10, feature11, feature12)
            return features

    def writeFeature(self, features, category):
        #1 = SSC
        #2 = SCA
        #3 = SCA in debug mode
        featurestring = ""
        for feature in features:
            featurestring = featurestring + str(feature) + '\t'

        with open('features', 'ab') as f: f.write(featurestring + '\t' + str(category) + '\n')











nn = NN()

logmessages = nn.readLogfile('ssc.log.1')
nn.getUniqueWordCount(logmessages)
nn.normalizeWordCount()

#nn.printUniqueWords(1)

features = nn.extractFeatures()

#1 = SSC
#2 = SCA
#3 = SCA in debug mode

nn.writeFeature(features, 1)








